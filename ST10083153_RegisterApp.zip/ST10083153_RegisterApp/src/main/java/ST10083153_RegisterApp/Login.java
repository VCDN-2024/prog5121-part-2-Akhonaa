/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ST10083153_RegisterApp;

import java.util.Scanner;
import javax.swing.JOptionPane;
import java.util.ArrayList;

public class App {
   private static ArrayList<Task> taskList = new ArrayList<>();

    public static void main(String[] args) {
        String Username, Password;
        
        Scanner newScanner = new Scanner(System.in);
        
        System.out.println("Enter Username");
        
        Username = newScanner.nextLine();
        
        System.out.println("Enter Password");
        
        Password = newScanner.nextLine();
        
        if (Username.length() <= 5 && Username.contains(Password))
        {
            System.out.println("Username succesfully captured");
           
        }
        else{
            System.out.println("?Password is not \n" +
"correctly formatted, \n" +
"please ensure that \n" +
"the password \n" +
"contains at least 8 \n" +
"characters, a capital \n" +
"letter, a number and \n" +
"a special character");
            
            JOptionPane.showMessageDialog(null,"Enter username: ");
                 JOptionPane.showMessageDialog(null,"Enter password: ");
                        JOptionPane.showMessageDialog(null,"Username successfully captured ");
                        

    boolean Valid = true;
            if (Password.length() < 8)
            {
                Valid = false;
                System.out.println("Password is too short");
            }
            if (!Password.matches(".*[A-Z].*")){
            Valid = false;
                    System.out.println("Password is too short");

        }
            if(!Password.matches(".*\\d.*")){
                Valid = false;
             System.out.println("Password must contain atleast one number");

            }
            if(!Password.matches(".*[!@#$%^&*()].*")){
                Valid= false;
                   System.out.println("Password must contain atleast one special character");

            }
            if(Valid){
             System.out.println("successfully captured");
                
            }
            else{
      System.out.println("Password is not \n" +
"correctly formatted, \n" +
"please ensure that \n" +
"the password \n" +
"contains at least 8 \n" +
"characters, a capital \n" +
"letter, a number and \n" +
"a special character");

            }


        }
        
        
        
        
        
    }
    // Method to display the main menu and return user's choice
    private static int displayMenu() {
        String menu = "Select an option:\n" +
                      "1. Add tasks\n" +
                      "2. Show report\n" +
                      "3. Quit";
        String choiceStr = JOptionPane.showInputDialog(null, menu);
        int choice = Integer.parseInt(choiceStr);
        return choice;
    }
    
    // Method to add tasks
    private static void addTasks() {
        int numTasks = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter the number of tasks:"));
        for (int i = 0; i < numTasks; i++) {
            String taskName = JOptionPane.showInputDialog(null, "Enter task name:");
            String taskDescription = JOptionPane.showInputDialog(null, "Enter task description:");
            String developerDetails = JOptionPane.showInputDialog(null, "Enter developer details:");
            int taskDuration = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter task duration in hours:"));

            Task task = new Task(taskName, taskDescription, developerDetails, taskDuration);

            if (!task.checkTaskDescription()) {
                JOptionPane.showMessageDialog(null, "Please enter a task description of less than 50 characters.");
                continue;
            }
            String taskDetails = task.printTaskDetails();
            JOptionPane.showMessageDialog(null, taskDetails);

            taskList.add(task);
        }

        int totalHours = returnTotalHours();
        JOptionPane.showMessageDialog(null, "Total Hours: " + totalHours);
    }
    
    // Method to calculate the total combined hours of all entered tasks
    private static int returnTotalHours() {
        int totalHours = 0;
        for (Task task : taskList) {
            totalHours += task.getTaskDuration();
        }
        return totalHours;
    }
}

