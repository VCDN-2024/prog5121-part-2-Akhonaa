﻿namespace RecipeApplication2
{
    internal class Program
    {
        private static Recipe recipe = new Recipe(); //created object for the Recipe class
        private static RecipeUtil recipeUtil = new RecipeUtil(); //created object for the RecipeUtil class

        public delegate void checkCalory(int calories); //delegate method for calory notification
        public static checkCalory check = new checkCalory(caloryCheck);
        private static int totalColories;

        private static void Main(string[] args)
        {
            Console.WriteLine("What would you like to do?");
            Console.WriteLine("1. Add a new recipe");
            Console.WriteLine("2. Display the full recipe");
            Console.WriteLine("3. Choose which recipe to display");
            Console.WriteLine("4. Display all the recipes");
            Console.WriteLine("5. Scale the recipe");
            Console.WriteLine("6. Clear all data");
            Console.WriteLine("7. Exit");

            while (true)
            {
                Console.Write("Enter your choice: ");
                int menuChoice = Convert.ToInt32(Console.ReadLine());

                switch (menuChoice)
                {
                    case 1:
                        AddNewRecipe();
                        break;
                    case 2:
                        DisplayRecipe();
                        break;
                    case 3:
                        DisplayARecipe();
                        break;
                    case 4:
                        DisplayAllRecipes();
                        break;
                    case 5:
                        ScaleRecipe();
                        break;
                    case 6:
                        ClearRecipe();
                        break;
                    case 7:
                        return;
                    default:
                        Console.WriteLine("Invalid choice, please enter a valid option.");
                        break;
                }
            }
        }

        private static void AddNewRecipe()
        {
            Console.WriteLine("Enter the name of the recipe");
            string recipeName = Console.ReadLine();

            Recipe recipe = new Recipe();
            recipe.RecipeName = recipeName;

            bool addingIngredients = true;
            while (addingIngredients)
            {
                Console.WriteLine("Enter the name of the ingredient (or type 'done' to finish):");
                string ingredientName = Console.ReadLine();
                if (ingredientName.ToLower() == "done") break;

                Console.WriteLine("Please enter the quantity");
                double ingredientQuantity = Convert.ToDouble(Console.ReadLine());

                Console.WriteLine("Please enter the unit of measurement");
                string unitOfMeas = Console.ReadLine();

                Console.WriteLine("Please enter the number of calories");
                int calories = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Please enter the food group the ingredient belongs to");
                string foodGroup = Console.ReadLine();

                Ingredient ingredient = new Ingredient(ingredientName, ingredientQuantity, unitOfMeas, calories, foodGroup);
                recipe.IngredientsList.Add(ingredient);

                Console.WriteLine("New ingredient added.");
            }

            bool addingSteps = true;
            while (addingSteps)
            {
                Console.WriteLine("Enter the step description (or type 'done' to finish):");
                string stepDescription = Console.ReadLine();
                if (stepDescription.ToLower() == "done") break;

                recipe.StepsList.Add(stepDescription);
                Console.WriteLine("New step added.");
            }

            recipe.TotalCalories = recipe.IngredientsList.Sum(ingredient => ingredient.Calories);

            if (recipe.TotalCalories > 300)
            {
                Console.WriteLine("Warning: This recipe exceeds 300 calories.");
            }

            recipeUtil.AddNewRecipe(recipe);

            Console.WriteLine("New recipe added successfully.");
        }

        private static void DisplayRecipe()
        {
            Console.WriteLine("Recipe:");
            Console.WriteLine("Ingredients:");

            foreach (Ingredient ingredient in recipe.IngredientsList)
            {
                Console.WriteLine($"- {ingredient.IngredientName}, {ingredient.IngredientQuantity} {ingredient.UnitOfMeas}");
            }

            Console.WriteLine("Steps:");

            for (int i = 0; i < recipe.StepsList.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {recipe.StepsList[i]}");
            }

            int totalCalories = recipe.IngredientsList.Sum(ingredient => ingredient.Calories);
            recipe.TotalCalories = totalCalories;
            Console.WriteLine($"Total number of calories: {totalCalories}");
        }

        private static void DisplayARecipe()
        {
            Console.WriteLine("Please enter the name of a recipe");
            string recipeName = Console.ReadLine();

            recipeUtil.DisplayRecipeDetails(recipeName);
        }

        private static void DisplayAllRecipes()
        {
            recipeUtil.DisplayRecipes();
        }

        private static void ScaleRecipe()
        {
            Console.WriteLine("Enter the scale factor (0.5, 2, or 3):");
            double scaleFactor = Convert.ToDouble(Console.ReadLine());

            recipe.ScaleIngredients(scaleFactor);

            Console.WriteLine("Recipe scaled successfully.");
        }

        private static void ClearRecipe()
        {
            recipe.IngredientsList.Clear();
            recipe.StepsList.Clear();
            recipe.Clear();
            Console.WriteLine("Recipe data cleared successfully.");
        }

        public static void caloryCheck(int TotalCalories)
        {
        }

        public static int caloryCalculator(int AllCalsAdded)
        {
            totalColories = AllCalsAdded;
            return totalColories;
        }
    }
}
