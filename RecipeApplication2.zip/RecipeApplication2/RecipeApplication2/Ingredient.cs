﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeApplication2
{
    internal class Ingredient
    {
        //properties
        public string IngredientName { get; set; }

        public string UnitOfMeas { get; set; }
        public double IngredientQuantity { get; internal set; }

        //calories and foodGroup added for part 2
        public int Calories { get; set; }
        public string FoodGroup { get; set; }

        public Ingredient(string name, double quantity, string unit, int calories, string foodGroup)
        {
            IngredientName = name;
            IngredientQuantity = quantity;
            UnitOfMeas = unit;
            Calories = calories;
            FoodGroup = foodGroup;
        }

        public void Scale(double factor)
        {
            IngredientQuantity *= factor;
        }

        public override string ToString()//ToString method to return thr object as string
        {
            return $"{IngredientQuantity} {UnitOfMeas} {IngredientName}";
        }
    }
}
