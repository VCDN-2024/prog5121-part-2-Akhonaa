﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeApplication2
{
    internal class Steps
    {
        public Steps(string steps)

        {
            StepsDescription = steps;
        }
        //properties
        public string steps { get; }
        public string StepsDescription { get; }
    }
}
