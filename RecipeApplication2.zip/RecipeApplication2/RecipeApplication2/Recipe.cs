﻿namespace RecipeApplication2
{
    internal class Recipe
    {
        public List<Ingredient> IngredientsList { get; set; }
        public List<string> StepsList { get; set; }
        public string RecipeName { get; set; }
        public int TotalCalories { get; set; }

        public Recipe()
        {
            IngredientsList = new List<Ingredient>();
            StepsList = new List<string>();
        }

        public void ScaleIngredients(double scaleFactor)
        {
            foreach (Ingredient ingredient in IngredientsList)
            {
                ingredient.Scale(scaleFactor);
            }
        }

        public void Clear()
        {
            IngredientsList.Clear();
            StepsList.Clear();
            RecipeName = string.Empty;
            TotalCalories = 0;
        }
    }
}
