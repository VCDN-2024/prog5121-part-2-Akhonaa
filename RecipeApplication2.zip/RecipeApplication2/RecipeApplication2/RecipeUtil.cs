﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeApplication2
{
    internal class RecipeUtil //newly added class
    {
        public List<Recipe> RecipesList { get; set; }

        public RecipeUtil()
        {
            RecipesList = new List<Recipe>();
        }
        //method for adding a new recipe
        public void AddNewRecipe(Recipe recipe)
        {
            RecipesList.Add(recipe);
        }

        //method for displaying list of all recipes
        public void DisplayRecipes()
        {
            if (RecipesList.Count == 0)
            {
                Console.WriteLine("No recipes found.");
                return;
            }

            Console.WriteLine("List of Recipes:");
            foreach (Recipe recipe in RecipesList.OrderBy(r => r.RecipeName))
            {
                Console.WriteLine(recipe.RecipeName);
            }
        }

        //method which displays details of a recipe
        public void DisplayRecipeDetails(string recipeName)
        {
            Recipe recipe = RecipesList.FirstOrDefault(r => r.RecipeName == recipeName);
            if (recipe == null)
            {
                Console.WriteLine("Recipe not found.");
                return;
            }

            Console.WriteLine("Recipe Details:");
            Console.WriteLine($"Name: {recipe.RecipeName}");
            Console.WriteLine("Ingredients:");
            foreach (Ingredient ingredient in recipe.IngredientsList)
            {
                Console.WriteLine($"- {ingredient.IngredientName}, {ingredient.IngredientQuantity} {ingredient.UnitOfMeas}");
            }

            Console.WriteLine("Steps:");
            foreach (string step in recipe.StepsList)
            {
                Console.WriteLine(step);
            }

            Console.WriteLine($"Total Calories: {recipe.TotalCalories}");

            //if (recipe.TotalCalories > 300)
            //{
            //Console.WriteLine("Warning: This recipe exceeds 300 calories.");
            // }
        }
        //excepetion handling for 'DisplayRecipeDetails()' method
        internal static void DisplayRecipeDetails()
        {
            throw new NotImplementedException();
        }
    }
}
