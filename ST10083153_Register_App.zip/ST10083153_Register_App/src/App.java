import javax.swing.JOptionPane;
import java.util.ArrayList;

public class App {
    private static ArrayList<Task> taskList = new ArrayList<>();

    public static void main(String[] args) {
        String username, password;

        username = JOptionPane.showInputDialog(null, "Enter Username");
        password = JOptionPane.showInputDialog(null, "Enter Password");

        if (username.length() <= 5 && username.contains(password)) {
            JOptionPane.showMessageDialog(null, "Username successfully captured");
        } else {
            JOptionPane.showMessageDialog(null, "Password is not correctly formatted. Please ensure that the password contains at least 8 characters, a capital letter, a number, and a special character");

            boolean valid = true;
            if (password.length() < 8) {
                valid = false;
                JOptionPane.showMessageDialog(null, "Password is too short");
            }
            if (!password.matches(".*[A-Z].*")) {
                valid = false;
                JOptionPane.showMessageDialog(null, "Password must contain at least one uppercase letter");
            }
            if (!password.matches(".*\\d.*")) {
                valid = false;
                JOptionPane.showMessageDialog(null, "Password must contain at least one number");
            }
            if (!password.matches(".*[!@#$%^&*()].*")) {
                valid = false;
                JOptionPane.showMessageDialog(null, "Password must contain at least one special character");
            }
            if (valid) {
                JOptionPane.showMessageDialog(null, "Password successfully captured");
            } else {
                JOptionPane.showMessageDialog(null, "Password is not correctly formatted. Please ensure that the password contains at least 8 characters, a capital letter, a number, and a special character");
            }
        }
    }

    // Method to display the main menu and return user's choice
    private static int displayMenu() {
        String menu = "Select an option:\n" +
                      "1. Add tasks\n" +
                      "2. Show report\n" +
                      "3. Quit";
        String choiceStr = JOptionPane.showInputDialog(null, menu);
        int choice = Integer.parseInt(choiceStr);
        return choice;
    }

    // Method to add tasks
    private static void addTasks() {
        int numTasks = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter the number of tasks:"));
        for (int i = 0; i < numTasks; i++) {
            String taskName = JOptionPane.showInputDialog(null, "Enter task name:");
            String taskDescription = JOptionPane.showInputDialog(null, "Enter task description:");
            String developerDetails = JOptionPane.showInputDialog(null, "Enter developer details:");
            int taskDuration = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter task duration in hours:"));

            Task task = new Task(taskName, taskDescription, developerDetails, taskDuration);

            if (!task.checkTaskDescription()) {
                JOptionPane.showMessageDialog(null, "Please enter a task description of less than 50 characters.");
                continue;
            }
            String taskDetails = task.printTaskDetails();
            JOptionPane.showMessageDialog(null, taskDetails);

            taskList.add(task);
        }

        int totalHours = returnTotalHours();
        JOptionPane.showMessageDialog(null, "Total Hours: " + totalHours);
    }

    // Method to calculate the total combined hours of all entered tasks
    private static int returnTotalHours() {
        int totalHours = 0;
        for (Task task : taskList) {
            totalHours += task.getTaskDuration();
        }
        return totalHours;
    }
}
